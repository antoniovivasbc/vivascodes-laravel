var modal_1 = document.getElementById('modal');
function modal(){
    modal_1.style.visibility = 'visible';
    modal_1.style.opacity = '1';
}
function fecha_modal(){
    modal_1.style.opacity = '0';
    modal_1.style.visibility = 'hidden'; 
}
var modal_2 = document.getElementById('modal2');
function modal2(){
    modal_2.style.visibility = 'visible';
    modal_2.style.opacity = '1';
}
function fecha_modal2(){
    modal_2.style.opacity = '0';
    modal_2.style.visibility = 'hidden'; 
}